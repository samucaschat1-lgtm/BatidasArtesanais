# Substituição do primeiro carrossel — Biblioteca de Cachaças

Destino: `https://github.com/samucaschat1-lgtm/BatidasArtesanais`

O carrossel certo é o primeiro da página, sob o título **+200 BATIDAS NO MATERIAL COMPLETO**, com classe `.marquee`, no arquivo `src/routes/index.tsx`.

1. Adicione os 7 arquivos WebP desta pasta no diretório `public/assets/optimized-v1/` do repositório.
2. No primeiro carrossel de `src/routes/index.tsx`, substitua somente o array original com os arquivos `batida-out07-...webp` pelo array abaixo:

```tsx
[
  "cachaca-carrossel-01-canela_cravo.webp",
  "cachaca-carrossel-02-manga.webp",
  "cachaca-carrossel-03-amora.webp",
  "cachaca-carrossel-04-caju.webp",
  "cachaca-carrossel-05-pessego.webp",
  "cachaca-carrossel-06-maca_canela.webp",
  "cachaca-carrossel-07-abacaxi.webp"
]
```

Mantenha o `.map(...)`, a repetição dupla para rolagem infinita e o segundo carrossel de prévias sem mudanças. Não mexer nos pixels nem nos links de checkout.
